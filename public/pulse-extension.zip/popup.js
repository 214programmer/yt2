document.getElementById('btn').addEventListener('click', async () => {
  const code = document.getElementById('code').value;
  if (!code) { alert("Введите код!"); return; }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab.url.includes("v=")) { alert("Нужно быть на странице видео!"); return; }

  const btn = document.getElementById('btn');
  btn.disabled = true;
  document.getElementById('loading').style.display = 'block';
  document.getElementById('res').style.display = 'none';

  try {
    const response = await fetch("https://yt2-zeta.vercel.app/api/video-pulse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videoUrl: tab.url, accessCode: code })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Ошибка сервера");

    // Заполняем данные
    document.getElementById('views').innerText = Number(data.views).toLocaleString('ru-RU');
    document.getElementById('likes').innerText = Number(data.likes).toLocaleString('ru-RU');
    document.getElementById('subs').innerText = "+" + data.subs;
    document.getElementById('er').innerText = data.er;
    
    document.getElementById('secret').innerText = data.secret;
    document.getElementById('hook').innerText = data.hook;
    document.getElementById('advice').innerText = data.advice;
    
    document.getElementById('res').style.display = 'block';
  } catch (err) {
    alert("Ошибка: " + err.message);
  } finally {
    document.getElementById('loading').style.display = 'none';
    btn.disabled = false;
  }
});